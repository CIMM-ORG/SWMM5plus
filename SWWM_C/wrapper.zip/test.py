import swmm5_wrapper as swmm5
import os


swmm5.print_info('tanks.inp', swmm5.US)