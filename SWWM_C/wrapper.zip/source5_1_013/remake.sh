#!/bin/bash
rm *.o
rm *.so
make